<?php
/**
 * Plugin Name: voting-mobile-custom-plugin-v2.0 (Minister demo) — v6.5
 * Description: Full-bleed hlasovanie 'Volíme ministra' (demo). v5.3: mobil full-screen (100svh) + väčšia typografia a vertikálne centrovanie.
 * Version: 2.0.13-minister-v6.5
 * Author: Naše Voľby
 * License: GPL2
 * Requires at least: 5.0
 * Requires PHP: 7.2
 */
if (!defined('ABSPATH')) { exit; }

class Voting_Mobile_Custom_Minister_V65 {
  public function __construct(){
    add_shortcode('volba_ministra', [$this,'render']);
    add_shortcode('volba-ministra', [$this,'render']);
    add_shortcode('voting_mobile_custom_minister_v2', [$this,'render']);
    add_action('wp_enqueue_scripts', [$this,'assets']);
  }
  public function assets(){
    $ver='2.0.7-minister';
    wp_register_style('vmcv2-style', plugins_url('assets/style.css', __FILE__), [], $ver);
    wp_register_script('vmcv2-app', plugins_url('assets/app.js', __FILE__), [], $ver, true);
  }
  public function render($atts){
    $atts = shortcode_atts([
      'crest' => '',
      'vote_no' => '14/2025',
      'voter_name' => 'Miroslav Petre',
      'district' => '149',
      'title' => 'Voľba ministra',
      'bios_url' => 'https://hlasujeme.com/minule-hlasovania-buduce-hlasovania/volba-ministra/',
      'history_url' => 'https://hlasujeme.com/minule-hlasovania-buduce-hlasovania/571-2/',
      'total_voters' => '4360505',
      'full_bleed' => '1'
    ], $atts, 'voting_mobile_custom_minister_v2');
    // Default crest logo if not provided
    if (empty($atts['crest'])) {
      $atts['crest'] = plugins_url('assets/logo-nase-volby-clean.png', __FILE__);
    }


    wp_enqueue_style('vmcv2-style');
    wp_enqueue_script('vmcv2-app');

    $candidates = [
      ['id'=>'k1','name'=>'Kandidát č.1 MUDr. Jozef Král','bio'=>'(Životopis)'],
      ['id'=>'k2','name'=>'Kandidát č.2 MUDr. Jaroslav Princ','bio'=>'(Životopis)'],
      ['id'=>'k3','name'=>'Kandidát č.3 MUDr. Stanislav Doktor','bio'=>''],
      ['id'=>'k4','name'=>'Kandidát č.4 MUDr. Ivan Zubár','bio'=>''],
      ['id'=>'k5','name'=>'Kandidát č.5 MUDr. Ján Čakateľ','bio'=>''],
      ['id'=>'k6','name'=>'Kandidát č.6 MUDr. Alena Školená','bio'=>''],
      ['id'=>'k7','name'=>'Kandidát č.7 MUDr. Pavol Lekárník','bio'=>''],
    ];

    ob_start(); ?>
    <div id="vmcv2-app"
         class="vmcv2-wrap<?php echo ($atts['full_bleed']==='1' ? ' vmcv2-fullbleed' : ''); ?>"
         data-candidates='<?php echo json_encode($candidates, JSON_UNESCAPED_UNICODE); ?>'
         data-crest="<?php echo esc_url($atts['crest']); ?>"
         data-vote-no="<?php echo esc_attr($atts['vote_no']); ?>"
         data-voter-name="<?php echo esc_attr($atts['voter_name']); ?>"
         data-district="<?php echo esc_attr($atts['district']); ?>"
         data-title="<?php echo esc_attr($atts['title']); ?>"
         data-bios-url="<?php echo esc_url($atts['bios_url']); ?>"
         data-history-url="<?php echo esc_url($atts['history_url']); ?>"
         data-total-voters="<?php echo esc_attr($atts['total_voters']); ?>"
         data-today="<?php echo esc_attr( date_i18n('j.n.Y, H:i:s') ); ?>"
    >
      <noscript>Na spustenie hlasovania je potrebný JavaScript.</noscript>
    </div>
    <?php return ob_get_clean();
  }
}
new Voting_Mobile_Custom_Minister_V65();
