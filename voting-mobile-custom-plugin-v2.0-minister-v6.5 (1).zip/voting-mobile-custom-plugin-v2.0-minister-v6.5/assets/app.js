(function(){
  function el(t,a={},kids=[]){const e=document.createElement(t);Object.entries(a).forEach(([k,v])=>{if(k==='class')e.className=v;else if(k==='html')e.innerHTML=v;else if(k==='text')e.textContent=v;else e.setAttribute(k,v)});kids.forEach(k=>e.appendChild(k));return e;}
  function lockBody(){ try{ document.body.classList.add('vmcv2-lock'); }catch(e){} }

  function codeInputs(autofocus){
    const wrap=el('div',{class:'vmcv2-codeboxes'});
    const boxes=[];
    for(let i=0;i<5;i++){
      const b=el('input',{type:'text',inputmode:'numeric',maxlength:'1',autocomplete:'one-time-code',pattern:'\\d*'});
      boxes.push(b); wrap.appendChild(b);
    }
    boxes.forEach((b,i)=>{
      b.addEventListener('beforeinput', e=>{ if(e.data && !/^[0-9]$/.test(e.data)) e.preventDefault(); });
      b.addEventListener('focus', ()=>{ try{ b.scrollIntoView({block:'center'});}catch(e){} });
      b.addEventListener('input', ()=>{ if(b.value && i<4) boxes[i+1].focus(); });
      b.addEventListener('keydown', e=>{
        if(e.key==='Backspace' && !b.value && i>0){ boxes[i-1].focus(); }
        if(e.key>='0' && e.key<='9'){ b.value=e.key; if(i<4) boxes[i+1].focus(); e.preventDefault(); }
      });
      b.addEventListener('paste', e=>{
        e.preventDefault();
        const txt=(e.clipboardData.getData('text')||'').replace(/\D/g,'');
        for(let j=0;j<Math.min(5,txt.length);j++){ boxes[j].value=txt[j]; }
        const idx=Math.min(4, txt.length-1); (boxes[idx]||boxes[0]).focus();
      });
    });
    if(autofocus) setTimeout(()=>{ boxes[0].focus(); }, 120);
    return {wrap,boxes};
  }

  function seededRand(seed){ let x=0; for(let i=0;i<seed.length;i++){ x=(x*31 + seed.charCodeAt(i))>>>0; } return function(){ x=(1103515245*x + 12345) % 0x80000000; return x/0x80000000; }; }
  function genTallies(cands, total, seedStr, winnerId){
    const rand = seededRand(seedStr);
    const rest = total * 0.4, winnerVotes = Math.floor(total * 0.6);
    const others = cands.filter(c=>c.id!==winnerId);
    const weights = others.map(()=>0.5 + rand()*1.5);
    const wsum = weights.reduce((a,b)=>a+b,0) || 1;
    const tally = {}; tally[winnerId]=winnerVotes;
    others.forEach((c,i)=>{ tally[c.id]=Math.floor(rest*(weights[i]/wsum)); });
    let diff = total - Object.values(tally).reduce((a,b)=>a+b,0); if(diff!==0){ tally[winnerId]+=diff; }
    return tally;
  }

  function render(){
    const root=document.getElementById('vmcv2-app'); if(!root) return; lockBody();

    const crest=root.getAttribute('data-crest')||'';
    const voteNo=root.getAttribute('data-vote-no')||'';
    const voter=root.getAttribute('data-voter-name')||'';
    const district=root.getAttribute('data-district')||'';
    const title=root.getAttribute('data-title')||'Voľba ministra';
    const biosUrl=root.getAttribute('data-bios-url')||'#';
    const historyUrl=root.getAttribute('data-history-url')||'#';
    const today=root.getAttribute('data-today')||'';
    const totalVoters=parseInt(root.getAttribute('data-total-voters')||'4360505',10);
    const candidates=JSON.parse(root.getAttribute('data-candidates')||'[]');

    const card=el('div',{class:'vmcv2-card'});

    function step0(){
      card.innerHTML='';
      card.classList.add('vmcv2-intro');
      if(crest) card.appendChild(el('img',{src:crest, alt:'Crest', class:'vmcv2-crest'}));
      card.appendChild(el('div',{class:'vmcv2-h1', html: title}));
      card.appendChild(el('div',{class:'vmcv2-text', text:'Dnes je '+today}));
      const cd=el('div',{class:'vmcv2-text', id:'vmcv2-countdown'}); card.appendChild(cd);
      card.appendChild(el('div',{class:'vmcv2-text', text:'Volič: '+voter+', Obvod č. '+district}));
      let cdTimer = setInterval(()=>tickCountdown(document.getElementById('vmcv2-countdown')), 1000);
      tickCountdown(document.getElementById('vmcv2-countdown'));
      const next=el('button',{class:'vmcv2-btn',text:'Ďalej'});
      next.addEventListener('click', stepCode);
      card.appendChild(next);
      const row=el('div',{class:'vmcv2-row'},[
        el('a',{href:biosUrl,target:'_blank',class:'vmcv2-small-btn',text:'Osobné životopisy'}),
        el('a',{href:historyUrl,target:'_blank',rel:'noopener',class:'vmcv2-small-btn',text:'História hlasovaní'})
      ]);
      card.appendChild(row);
    }

    function stepCode(){
      card.innerHTML='';
      card.classList.remove('vmcv2-intro');
      if(crest) card.appendChild(el('img',{src:crest, alt:'Crest', class:'vmcv2-crest'}));
      card.appendChild(el('div',{class:'vmcv2-h2', text:'Zadajte kód'}));
      card.appendChild(el('div',{class:'vmcv2-text', text:'Som oboznámený s obsahom a podmienkami hlasovania a nebudem pripojený k internetu počas hlasovania.'}));
      const {wrap,boxes}=codeInputs(true); card.appendChild(wrap);
      const err=el('div',{class:'vmcv2-error'}); card.appendChild(err);
      const btn=el('button',{class:'vmcv2-btn',text:'Ďalej'});
      btn.addEventListener('click', ()=>{
        const val=boxes.map(b=>b.value||'').join('');
        if(!/^\d{5}$/.test(val)){ err.textContent='Zadajte 5-miestny číselný kód.'; boxes[0].focus(); return; }
        stepVote();
      });
      card.appendChild(btn);
    }

    function stepVote(){
      card.innerHTML='';
      if(crest) card.appendChild(el('img',{src:crest, alt:'Crest', class:'vmcv2-crest'}));
      card.appendChild(el('div',{class:'vmcv2-h2', text:'Volíme ministra'}));
      const list=el('div',{class:'vmcv2-list'}); let selected=null;
      candidates.forEach(c=>{
        const item=el('div',{class:'vmcv2-item', html:'<strong>'+c.name+'</strong> <span class="vmcv2-text">'+(c.bio||'')+'</span>'});
        item.addEventListener('click', ()=>{
          list.querySelectorAll('.vmcv2-item').forEach(i=>i.classList.remove('selected'));
          item.classList.add('selected'); selected=c;
        });
        list.appendChild(item);
      });
      card.appendChild(list);
      const err=el('div',{class:'vmcv2-error'}); card.appendChild(err);
      let cdTimer = setInterval(()=>tickCountdown(document.getElementById('vmcv2-countdown')), 1000);
      tickCountdown(document.getElementById('vmcv2-countdown'));
      const next=el('button',{class:'vmcv2-btn',text:'Ďalej'});
      next.addEventListener('click', ()=>{
        if(!selected){ err.textContent='Prosím, vyberte jedného kandidáta.'; return; }
        stepConfirm(selected);
      });
      card.appendChild(next);
    }

    function stepConfirm(sel){
      card.innerHTML='';
      if(crest) card.appendChild(el('img',{src:crest, alt:'Crest', class:'vmcv2-crest'}));
      card.appendChild(el('div',{class:'vmcv2-h2', text:'Skontrolujte a potvrďte voľbu'}));
      card.appendChild(el('div',{class:'vmcv2-text', html:'<strong>Váš výber:</strong> '+sel.name}));
      const row=el('div',{class:'vmcv2-row'},[
        el('button',{class:'vmcv2-btn',text:'Späť'}),
        el('button',{class:'vmcv2-btn',text:'Potvrdiť voľbu'}),
      ]);
      row.children[0].addEventListener('click', stepVote);
      row.children[1].addEventListener('click', ()=>{
        try{ localStorage.setItem('vmcv2_vote', JSON.stringify({id:sel.id,name:sel.name,ts:Date.now()})); }catch(e){}
        stepThanks(sel);
      });
      card.appendChild(row);
    }

    function stepThanks(sel){
      card.innerHTML='';
      if(crest) card.appendChild(el('img',{src:crest, alt:'Crest', class:'vmcv2-crest'}));
      card.appendChild(el('div',{class:'vmcv2-h2', text:'Ďakujeme za váš hlas, ktorý prispel na spravodlivé riadenie štátu!'}));
      const totalVoters = parseInt(root.getAttribute('data-total-voters')||'4360505',10);
      const tally = genTallies(candidates, totalVoters, (voteNo||'seed'), candidates[0].id);
      tally[sel.id]=(tally[sel.id]||0)+1;
      const box=el('div',{class:'vmcv2-tally'});
      candidates.forEach(c=>{
        const n=tally[c.id]||0, pct = totalVoters>0 ? Math.round((n/totalVoters)*1000)/10 : 0;
        box.appendChild(el('div',{class:'vmcv2-tally-row'},[
          el('div',{class:'vmcv2-tally-name', text:c.name}),
          el('div',{class:'vmcv2-tally-num', text: n.toLocaleString('sk-SK')+' ('+pct+'%)'})
        ]));
      });
      card.appendChild(box);
      const row=el('div',{class:'vmcv2-row'},[
        el('button',{class:'vmcv2-btn',text:'Overiť môj hlas'}),
        el('button',{class:'vmcv2-btn',text:'Ukončiť hlasovanie'}),
      ]);
      row.children[0].addEventListener('click', ()=>alert('Demo: hlas je uložený len lokálne.'));
      row.children[1].addEventListener('click', step0);
      card.appendChild(row);
    }

    
    function pad(n){ return String(n).padStart(2,'0'); }
    function tickCountdown(el){
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0);
      const end   = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 18, 0, 0);
      let text = '';
      if(now < start){
        const diff = start - now;
        const h = Math.floor(diff/3600000);
        const m = Math.floor((diff%3600000)/60000);
        const s = Math.floor((diff%60000)/1000);
        text = 'Hlasovanie sa začne o: ' + pad(h)+':'+pad(m)+':'+pad(s);
      } else if(now >= start && now <= end){
        const diff = end - now;
        const h = Math.floor(diff/3600000);
        const m = Math.floor((diff%3600000)/60000);
        const s = Math.floor((diff%60000)/1000);
        text = 'Zostáva do konca hlasovania: ' + pad(h)+':'+pad(m)+':'+pad(s);
      } else {
        text = 'Hlasovanie je ukončené';
      }
      if(el) el.textContent = text;
    }
    
    root.innerHTML=''; root.appendChild(card);
    step0();
  }

  window.genTallies = genTallies;

  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded',render); } else { render(); }
})();
