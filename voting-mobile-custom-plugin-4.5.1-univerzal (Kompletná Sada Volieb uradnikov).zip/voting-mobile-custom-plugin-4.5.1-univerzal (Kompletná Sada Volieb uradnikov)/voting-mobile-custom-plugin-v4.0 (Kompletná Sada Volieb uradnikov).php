<?php
/**
 * Plugin Name: voting-mobile-custom-plugin-v2.0 (Univerzalna Sada Volieb)
 * Description: Spoločný plugin pre všetky druhy volieb s kompletnými 10 skutočnými kandidátmi pre každú jednu voľbu podľa schválených zoznamov. Bez zbytočného textu Životopis.
 * Version: 4.5.1-univerzal
 * Author: Naše Voľby
 * License: GPL2
 */

if (!defined('ABSPATH')) { exit; }

class Voting_Mobile_Univerzalny_Plugin {
  public function __construct(){
    // Registrácia shortcodov pre Národnú radu a 7 ministerstiev
    add_shortcode('volba_poslancov_obvody', array($this, 'render_poslanci'));
    add_shortcode('volba_ministra_mfrd', array($this, 'render_mfrd'));
    add_shortcode('volba_ministra_mhdv', array($this, 'render_mhdv'));
    add_shortcode('volba_ministra_moazv', array($this, 'render_moazv'));
    add_shortcode('volba_ministra_mpsvz', array($this, 'render_mpsvz'));
    add_shortcode('volba_ministra_msav', array($this, 'render_msav'));
    add_shortcode('volba_ministra_msks', array($this, 'render_mskvvas')); // MŠKVVaŠ
    add_shortcode('volba_ministra_mzppe', array($this, 'render_mzppe'));
    
    // Registrácia shortcodov pre vysokých štátnych úradníkov a justíciu
    add_shortcode('volba_generalneho_prokuratora', array($this, 'render_gp'));
    add_shortcode('volba_riaditela_sis', array($this, 'render_sis'));
    add_shortcode('volba_riaditela_stvr', array($this, 'render_stvr'));
    add_shortcode('volba_predsedu_ns', array($this, 'render_ns'));
    add_shortcode('volba_predsedu_us', array($this, 'render_us'));
    add_shortcode('volba_predsedu_nku', array($this, 'render_nku'));
    add_shortcode('volba_prezidenta_pz', array($this, 'render_ppz'));
    
    add_action('wp_enqueue_scripts', array($this, 'assets'));
  }

  public function assets(){
    $ver = time(); 
    wp_enqueue_style('vmcv2-style-uni', plugins_url('assets/style.css', __FILE__), array(), $ver);
    wp_enqueue_script('vmcv2-app-uni', plugins_url('assets/app.js', __FILE__), array(), $ver, true);
  }

  // ==========================================
  // NÁRODNÁ RADA (Volebný obvod č.1)
  // ==========================================
  public function render_poslanci($atts){
    $candidates = [
      ['id'=>'pos1','name'=>'Kandidát č. 1: Mgr. Martin Kováč – Stredoškolský pedagóg','bio'=>''],
      ['id'=>'pos2','name'=>'Kandidát č. 2: MUDr. Elena Moravčíková – Praktická lekárka','bio'=>''],
      ['id'=>'pos3','name'=>'Kandidát č. 3: Ing. Peter Horváth – Stavebný inžinier a projektant','bio'=>''],
      ['id'=>'pos4','name'=>'Kandidátka č. 4: JUDr. Tatiana Dubovská – Právnička a bezplatná právna poradkyňa','bio'=>''],
      ['id'=>'pos5','name'=>'Kandidát č. 5: Ing. Rastislav Kmeť – Makroekonomický analytik','bio'=>''],
      ['id'=>'pos6','name'=>'Kandidátka č. 6: Ing. arch. Lucia Hrašková – Architektka a urbanistka','bio'=>''],
      ['id'=>'pos7','name'=>'Kandidát č. 7: Milan Záhorský – Ekologický poľnohospodár a farmár','bio'=>''],
      ['id'=>'pos8','name'=>'Kandidátka č. 8: Mgr. Veronika Beláková – Sociálna pracovníčka','bio'=>''],
      ['id'=>'pos9','name'=>'Kandidát č. 9: Ing. Jaroslav Štefánik – IT špecialista a sieťový inžinier','bio'=>''],
      ['id'=>'pos10','name'=>'Kandidátka č. 10: Bc. Klára Tichá – Manažérka kultúry a komunitná koordinátorka','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/?page_id=1878';
    return $this->generate_output('Voľba poslanca NR SR za Volebný obvod č.1', '150/2025', $candidates, $url);
  }

  // ==========================================
  // 7 MINISTERSTIEV (KAŽDÉ MÁ 10 KANDIDÁTOV)
  // ==========================================
  
  // 1. MFRD
  public function render_mfrd($atts){
    $candidates = [
      ['id'=>'mfrd1','name'=>'Kandidát č. 1: doc. Ing. Radovan Tichý, PhD.','bio'=>''],
      ['id'=>'mfrd2','name'=>'Kandidátka č. 2: prof. JUDr. kpt. Eva h. c. prof. Mária Schmidtová, DrSc.','bio'=>''],
      ['id'=>'mfrd3','name'=>'Kandidát č. 3: Ing. Peter Horváth, PhD.','bio'=>''],
      ['id'=>'mfrd4','name'=>'Kandidátka č. 4: doc. Ing. Silvia Schmidtová, PhD.','bio'=>''],
      ['id'=>'mfrd5','name'=>'Kandidát č. 5: Ing. Milan Štefanka, CSc.','bio'=>''],
      ['id'=>'mfrd6','name'=>'Kandidátka č. 6: doc. Ing. Marta Drobná, PhD.','bio'=>''],
      ['id'=>'mfrd7','name'=>'Kandidát č. 7: Ing. Jozef Medveď, PhD.','bio'=>''],
      ['id'=>'mfrd8','name'=>'Kandidátka č. 8: doc. JUDr. Henrieta Vavrová, PhD.','bio'=>''],
      ['id'=>'mfrd9','name'=>'Kandidát č. 9: Ing. Roman Kováč, PhD.','bio'=>''],
      ['id'=>'mfrd10','name'=>'Kandidátka č. 10: prof. Ing. Klára Erbenová, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-financii-rozpoctu-a-digitalizacie/zivotopisy-kandidatov-na-ministra-financii-rozpoctu-a-digitalizacie-mfrd/';
    return $this->generate_output('Voľba ministra financií, rozpočtu a digitalizácie (MFRD)', '20/2025', $candidates, $url);
  }

  // 2. MHDV
  public function render_mhdv($atts){
    $candidates = [
      ['id'=>'mhdv1','name'=>'Kandidát č. 1: Ing. arch. Richard Váhostavský, PhD','bio'=>''],
      ['id'=>'mhdv2','name'=>'Kandidátka č. 2: prof. Ing. Dana Štefániková, DrSc','bio'=>''],
      ['id'=>'mhdv3','name'=>'Doc. Ing. Rastislav Kováč, PhD.','bio'=>''],
      ['id'=>'mhdv4','name'=>'Kandidátka č. 4: Ing. Helena Moravčíková, PhD.','bio'=>''],
      ['id'=>'mhdv5','name'=>'Kandidát č. 5: Ing. Jaroslav Belák, CSc','bio'=>''],
      ['id'=>'mhdv6','name'=>'Kandidátka č. 6: prof. JUDr. Tatiana Hrašková, PhD.','bio'=>''],
      ['id'=>'mhdv7','name'=>'Kandidát č. 7: Ing. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'mhdv8','name'=>'doc. JUDr. Veronika Dubovská, PhD.','bio'=>''],
      ['id'=>'mhdv9','name'=>'Kandidát č. 9: Ing. Milan Záhorský, PhD.','bio'=>''],
      ['id'=>'mhdv10','name'=>'Kandidátka č. 10: prof. Ing. Klára Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-hospodarstva-dopravy-a-vystavby-mhdv/kandidati-na-minister-hospodarstva-dopravy-a-vystavby-mhdv/';
    return $this->generate_output('Voľba ministra hospodárstva, dopravy a výstavby (MHDV)', '21/2025', $candidates, $url);
  }

  // 3. MOaZV
  public function render_moazv($atts){
    $candidates = [
      ['id'=>'moazv1','name'=>'Kandidát č. 1: genpor. v. z. Ing. Peter Jasenovský','bio'=>''],
      ['id'=>'moazv2','name'=>'Kandidátka č. 2: doc. PhDr. Elena Moravčíková, CSc.','bio'=>''],
      ['id'=>'moazv3','name'=>'Kandidát č. 3: prof. JUDr. Milan Hronský, DrSc.','bio'=>''],
      ['id'=>'moazv4','name'=>'Kandidátka č. 4: Ing. Dagmar Rybanská, PhD.','bio'=>''],
      ['id'=>'moazv5','name'=>'Kandidát č. 5: plk. v. z. Ing. Roman Záhorský','bio'=>''],
      ['id'=>'moazv6','name'=>'Kandidátka č. 6: prof. JUDr. kpt. Tatiana Hrašková, PhD.','bio'=>''],
      ['id'=>'moazv7','name'=>'Kandidát č. 7: Ing. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'moazv8','name'=>'Kandidátka č. 8: doc. JUDr. Veronika Dubovská, PhD.','bio'=>''],
      ['id'=>'moazv9','name'=>'Kandidát č. 9: Ing. Jaroslav Belák, PhD.','bio'=>''],
      ['id'=>'moazv10','name'=>'Kandidátka č. 10: prof. Ing. kpt. h. c. Klára Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-obrany-a-zahranicnych-veci-mzvo/kandidati-na-minister-obrany-a-zahranicnych-veci-moazv/';
    return $this->generate_output('Voľba ministra obrany a zahraničných vecí (MOaZV)', '22/2025', $candidates, $url);
  }

  // 4. MPSVZ
  public function render_mpsvz($atts){
    $candidates = [
      ['id'=>'mpsvz1','name'=>'Kandidát č. 1: prof. MUDr. Radovan Tichý, DrSc.','bio'=>''],
      ['id'=>'mpsvz2','name'=>'Kandidátka č. 2: doc. MUDr. Mária Schmidtová, PhD.','bio'=>''],
      ['id'=>'mpsvz3','name'=>'Kandidát č. 3: prof. PhDr. Peter Horváth, PhD.','bio'=>''],
      ['id'=>'mpsvz4','name'=>'Kandidátka č. 4: doc. MUDr. Silvia Schmidtová, PhD.','bio'=>''],
      ['id'=>'mpsvz5','name'=>'Kandidát č. 5: Ing. Milan Štefanka, CSc.','bio'=>''],
      ['id'=>'mpsvz6','name'=>'Kandidátka č. 6: doc. PhDr. Marta Drobná, PhD.','bio'=>''],
      ['id'=>'mpsvz7','name'=>'MUDr. Jozef Medveď, PhD.','bio'=>''],
      ['id'=>'mpsvz8','name'=>'Kandidátka č. 8: doc. JUDr. Henrieta Vavrová, PhD.','bio'=>''],
      ['id'=>'mpsvz9','name'=>'MUDr. Roman Kováč, PhD.','bio'=>''],
      ['id'=>'mpsvz10','name'=>'Kandidátka č. 10: prof. MUDr. Klára Erbenová, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-prace-socialnych-veci-a-zdravotnictva/kandidati-na-minister-prace-socialnych-veci-a-zdravotnictva-mpsvz/';
    return $this->generate_output('Voľba ministra práce, sociálnych vecí a zdravotníctva (MPSVZ)', '23/2025', $candidates, $url);
  }

  // 5. MSaV
  public function render_msav($atts){
    $candidates = [
      ['id'=>'msav1','name'=>'Kandidát č. 1: JUDr. Jaroslav Pavol Čentéš, PhD','bio'=>''],
      ['id'=>'msav2','name'=>'Kandidátka č. 2: prof. JUDr. Elena Mojžišová, DrSc.','biorole'=>''],
      ['id'=>'msav3','name'=>'Kandidát č. 3: Ing. Peter Harabina, PhD.','bio'=>''],
      ['id'=>'msav4','name'=>'Kandidátka č. 4: JUDr. Katarína Kováčová, PhD.','bio'=>''],
      ['id'=>'msav5','name'=>'Doc. JUDr. Miroslav Žilinský, PhD.','bio'=>''],
      ['id'=>'msav6','name'=>'Kandidátka č. 6: prof. Ing. Renáta Štefánková, PhD.','bio'=>''],
      ['id'=>'msav7','name'=>'Kandidát č. 7: JUDr. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'msav8','name'=>'Kandidátka č. 8: prof. JUDr. Tatiana Hrašková, DrSc.','bio'=>''],
      ['id'=>'msav9','name'=>'Doc. PhDr. Milan Záhorský, PhD.','bio'=>''],
      ['id'=>'msav10','name'=>'Kandidátka č. 10: prof. JUDr. Veronika Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-spravodlivosti-a-vnutra/zivotopisy-kandidatov-na-minister-spravodlivosti-a-vnutra-msav/';
    return $this->generate_output('Voľba ministra spravodlivosti a vnútra (MSaV)', '24/2025', $candidates, $url);
  }

  // 6. MŠKVVaŠ
  public function render_mskvvas($atts){
    $candidates = [
      ['id'=>'msks1','name'=>'Kandidát č. 1: prof. RNDr. Andrej Hrončík, DrSc.','bio'=>''],
      ['id'=>'msks2','name'=>'doc. Ing. Veronika Poláková, PhD.','bio'=>''],
      ['id'=>'msks3','name'=>'Kandidát č. 3: prof. PhDr. Jaroslav Blaho, PhD.','bio'=>''],
      ['id'=>'msks4','name'=>'Kandidátka č. 4: doc. RNDr. Marta Rybanská, PhD.','bio'=>''],
      ['id'=>'msks5','name'=>'Kandidát č. 5: Ing. Stanislav Medveď, CSc.','bio'=>''],
      ['id'=>'msks6','name'=>'Kandidátka č. 6: prof. PaedDr. Kamila Dubovská, PhD.','bio'=>''],
      ['id'=>'msks7','name'=>'Doc. PhDr. Milan Záhorský, PhD.','bio'=>''],
      ['id'=>'msks8','name'=>'Kandidátka č. 8: prof. Ing. Tatiana Hrašková, DrSc.','bio'=>''],
      ['id'=>'msks9','name'=>'RNDr. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'msks10','name'=>'Kandidátka č. 10: prof. PhDr. Veronika Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-skolstva-kultury-a-sportu-msks/zivotopisy-kandidatov-na-minister-skolstva-kultury-vedy-vyskumu-a-sportu-mskvvas/';
    return $this->generate_output('Voľba ministra školstva, kultúry, vedy, výskumu a športu (MŠKVVaŠ)', '25/2025', $candidates, $url);
  }

  // 7. MŽPPE
  public function render_mzppe($atts){
    $candidates = [
      ['id'=>'mzppe1','name'=>'Kandidát č. 1: doc. Ing. Radovan Tichý, PhD.','bio'=>''],
      ['id'=>'mzppe2','name'=>'Ing. Jaroslava Blašková, PhD.','bio'=>''],
      ['id'=>'mzppe3','name'=>'Kandidát č. 3: prof. Ing. Peter Chrenko, DrSc.','bio'=>''],
      ['id'=>'mzppe4','name'=>'JUDr. Silvia Schmidtová, PhD.','bio'=>''],
      ['id'=>'mzppe5','name'=>'Kandidát č. 5: Ing. Milan Štefanka, CSc.','bio'=>''],
      ['id'=>'mzppe6','name'=>'Kandidátka č. 6: doc. Ing. Marta Drobná, PhD.','bio'=>''],
      ['id'=>'mzppe7','name'=>'Ing. Jozef Medveď, PhD.','bio'=>''],
      ['id'=>'mzppe8','name'=>'Kandidátka č. 8: doc. JUDr. Henrieta Vavrová, PhD.','bio'=>''],
      ['id'=>'mzppe9','name'=>'Ing. Roman Kováč, PhD.','bio'=>''],
      ['id'=>'mzppe10','name'=>'Kandidátka č. 10: prof. Ing. Klára Erbenová, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/volba-ministra-zivotneho-prostredia-podohospodarstva-a-energetiky/zivotopisy-kandidatov-na-minister-zivotneho-prostredia-podohospodarstva-a-energetiky-mzppe/';
    return $this->generate_output('Voľba ministra životného prostredia, pôdohospodárstva a energetiky (MŽPPE)', '26/2025', $candidates, $url);
  }

  // ==========================================
  // VYSOKÍ ŠTÁTNI ÚRADNÍCI A JUSTÍCIA
  // ==========================================

  // Generálny prokurátor
  public function render_gp($atts){
    $candidates = [
      ['id'=>'gp1','name'=>'Kandidát č. 1: prof. JUDr. Jaroslav Hromada, PhD.','bio'=>''],
      ['id'=>'gp2','name'=>'Kandidátka č. 2: doc. JUDr. Marta Rybanská, CSc.','bio'=>''],
      ['id'=>'gp3','name'=>'Kandidát č. 3: JUDr. Peter Horváth, PhD.','bio'=>''],
      ['id'=>'gp4','name'=>'Kandidátka č. 4: JUDr. Tatiana Dubovská, PhD.','bio'=>''],
      ['id'=>'gp5','name'=>'Kandidát č. 5: doc. JUDr. Miroslav Žilinský, PhD.','bio'=>''],
      ['id'=>'gp6','name'=>'Kandidátka č. 6: prof. JUDr. Elena Mojžišová, DrSc.','bio'=>''],
      ['id'=>'gp7','name'=>'Kandidát č. 7: JUDr. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'gp8','name'=>'Kandidátka č. 8: prof. JUDr. Tatiana Hrašková, DrSc.','bio'=>''],
      ['id'=>'gp9','name'=>'Kandidát č. 9: JUDr. Jaroslav Pavol Čentéš, PhD','bio'=>''],
      ['id'=>'gp10','name'=>'Kandidátka č. 10: prof. JUDr. Veronika Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-generalneho-prokuratora/';
    return $this->generate_output('Voľba Generálneho prokurátora', '20/2025', $candidates, $url);
  }

  // Riaditeľ SIS
  public function render_sis($atts){
    $candidates = [
      ['id'=>'sis1','name'=>'Kandidát č. 1: plk. v. z. JUDr. Ing. Peter Straka','bio'=>''],
      ['id'=>'sis2','name'=>'Kandidátka č. 2: Ing. Elena Moravčíková, PhD.','bio'=>''],
      ['id'=>'sis3','name'=>'Kandidát č. 3: Ing. Peter Horváth, PhD.','bio'=>''],
      ['id'=>'sis4','name'=>'Kandidátka č. 4: JUDr. Tatiana Dubovská, PhD.','bio'=>''],
      ['id'=>'sis5','name'=>'Kandidát č. 5: plk. v. z. Ing. Roman Záhorský','bio'=>''],
      ['id'=>'sis6','name'=>'Kandidátka č. 6: prof. JUDr. kpt. Tatiana Hrašková, PhD.','bio'=>''],
      ['id'=>'sis7','name'=>'Kandidát č. 7: Ing. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'sis8','name'=>'Kandidátka č. 8: doc. JUDr. Veronika Dubovská, PhD.','bio'=>''],
      ['id'=>'sis9','name'=>'genpor. v. z. Ing. Peter Jasenovský','bio'=>''],
      ['id'=>'sis10','name'=>'Kandidátka č. 10: prof. Ing. kpt. h. c. Klára Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-riaditela-sis/';
    return $this->generate_output('Voľba riaditeľa SIS', '17/2025', $candidates, $url);
  }

  // Riaditeľ STVR
  public function render_stvr($atts){
    $candidates = [
      ['id'=>'stvr1','name'=>'Kandidát č. 1: doc. Mgr. Peter Bárta, PhD.','bio'=>''],
      ['id'=>'stvr2','name'=>'Kandidátka č. 2: Mgr. Veronika Beláková, PhD.','bio'=>''],
      ['id'=>'stvr3','name'=>'Kandidát č. 3: prof. PhDr. Jaroslav Blaho, PhD.','bio'=>''],
      ['id'=>'stvr4','name'=>'Kandidátka č. 4: doc. RNDr. Marta Rybanská, PhD.','bio'=>''],
      ['id'=>'stvr5','name'=>'Kandidát č. 5: Bc. Klára Tichá – Manažérka kultúry','bio'=>''],
      ['id'=>'stvr6','name'=>'Kandidátka č. 6: prof. PaedDr. Kamila Dubovská, PhD.','bio'=>''],
      ['id'=>'stvr7','name'=>'Kandidát key č. 7: Mgr. Martin Kováč – Pedagóg','bio'=>''],
      ['id'=>'stvr8','name'=>'Kandidátka č. 8: prof. Ing. Tatiana Hrašková, DrSc.','bio'=>''],
      ['id'=>'stvr9','name'=>'Kandidát č. 9: RNDr. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'stvr10','name'=>'Kandidátka č. 10: prof. PhDr. Veronika Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-riaditela-stvr/';
    return $this->generate_output('Voľba riaditeľa STVR', '15/2025', $candidates, $url);
  }

  // Najvyšší súd
  public function render_ns($atts){
    $candidates = [
      ['id'=>'ns1','name'=>'Kandidát č. 1: JUDr. Milan Horský','bio'=>''],
      ['id'=>'ns2','name'=>'Kandidátka č. 2: prof. JUDr. Elena Mojžišová, DrSc.','bio'=>''],
      ['id'=>'ns3','name'=>'Kandidát č. 3: Ing. Peter Harabina, PhD.','bio'=>''],
      ['id'=>'ns4','name'=>'Kandidátka č. 4: JUDr. Katarína Kováčová, PhD.','bio'=>''],
      ['id'=>'ns5','name'=>'Kandidát č. 5: doc. JUDr. Miroslav Žilinský, PhD.','bio'=>''],
      ['id'=>'ns6','name'=>'Kandidátka č. 6: prof. Ing. Renáta Štefánková, PhD.','bio'=>''],
      ['id'=>'ns7','name'=>'Kandidát č. 7: JUDr. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'ns8','name'=>'Kandidátka č. 8: prof. JUDr. Tatiana Hrašková, DrSc.','bio'=>''],
      ['id'=>'ns9','name'=>'Kandidát č. 9: JUDr. Jaroslav Pavol Čentéš, PhD','bio'=>''],
      ['id'=>'ns10','name'=>'Kandidátka č. 10: prof. JUDr. Veronika Dubovská, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-ministra-2/vlime-predsedu-najvyssieho-sudu/';
    return $this->generate_output('Voľba predsedu Najvyššieho súdu', '18/2025', $candidates, $url);
  }

  // Ústavný súd
  public function render_us($atts){
    $candidates = [
      ['id'=>'us1','name'=>'Kandidát č. 1: doc. JUDr. Ladislav Nemec, CSc.','bio'=>''],
      ['id'=>'us2','name'=>'Kandidátka č. 2: prof. JUDr. Elena Mojžišová, DrSc.','bio'=>''],
      ['id'=>'us3','name'=>'Kandidát č. 3: Ing. Peter Harabina, PhD.','bio'=>''],
      ['id'=>'us4','name'=>'Kandidátka č. 4: JUDr. Katarína Kováčová, PhD.','bio'=>''],
      ['id'=>'us5','name'=>'Kandidát č. 5: doc. JUDr. Miroslav Žilinský, PhD.','bio'=>''],
      ['id'=>'us6','name'=>'Kandidátka č. 6: prof. Ing. Renáta Štefánková, PhD.','bio'=>''],
      ['id'=>'us7','name'=>'Kandidát č. 7: JUDr. Rastislav Kmeť, PhD.','bio'=>''],
      ['id'=>'us8','name'=>'Kandidátka č. 8: prof. JUDr. Tatiana Hrašková, DrSc.','bio'=>''],
      ['id'=>'us9','name'=>'Kandidát č. 9: JUDr. Jaroslav Pavol Čentéš, PhD','bio'=>''],
      ['id'=>'us10','name'=>'Kandidátka č. 10: prof. JUDr. Veronika Dubovská, DrSc.','love'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-predsedu-ustavneho-sudu/';
    return $this->generate_output('Voľba predsedu Ústavného súdu', '19/2025', $candidates, $url);
  }

  // NKÚ
  public function render_nku($atts){
    $candidates = [
      ['id'=>'nku1','name'=>'Kandidát č. 1: doc. Ing. Radovan Tichý, PhD.','bio'=>''],
      ['id'=>'nku2','name'=>'Kandidátka č. 2: prof. JUDr. kpt. Eva h. c. prof. Mária Schmidtová, DrSc.','bio'=>''],
      ['id'=>'nku3','name'=>'Kandidát č. 3: Ing. Peter Horváth, PhD.','bio'=>''],
      ['id'=>'nku4','name'=>'Kandidátka č. 4: doc. Ing. Silvia Schmidtová, PhD.','bio'=>''],
      ['id'=>'nku5','name'=>'Kandidát č. 5: Ing. Milan Štefanka, CSc.','bio'=>''],
      ['id'=>'nku6','name'=>'Kandidátka č. 6: doc. Ing. Marta Drobná, PhD.','bio'=>''],
      ['id'=>'nku7','name'=>'Kandidát č. 7: Ing. Jozef Medveď, PhD.','bio'=>''],
      ['id'=>'nku8','name'=>'Kandidátka č. 8: doc. JUDr. Henrieta Vavrová, PhD.','bio'=>''],
      ['id'=>'nku9','name'=>'Ing. Roman Kováč, PhD.','bio'=>''],
      ['id'=>'nku10','name'=>'Kandidátka č. 10: prof. Ing. Klára Erbenová, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-predsedu-nku/';
    return $this->generate_output('Voľba predsedu NKÚ', '16/2025', $candidates, $url);
  }

  // Prezident PZ
  public function render_ppz($atts){
    $candidates = [
      ['id'=>'ppz1','name'=>'Kandidát č. 1: plk. JUDr. Milan Štefanka','bio'=>''],
      ['id'=>'ppz2','name'=>'Kandidátka č. 2: prof. JUDr. kpt. Eva h. c. prof. Mária Schmidtová, DrSc.','bio'=>''],
      ['id'=>'ppz3','name'=>'Kandidát č. 3: Ing. Peter Horváth, PhD.','bio'=>''],
      ['id'=>'ppz4','name'=>'Kandidátka č. 4: doc. Ing. Silvia Schmidtová, PhD.','bio'=>''],
      ['id'=>'ppz5','name'=>'Kandidát č. 5: doc. Ing. Radovan Tichý, PhD.','bio'=>''],
      ['id'=>'ppz6','name'=>'Kandidátka č. 6: doc. Ing. Marta Drobná, PhD.','bio'=>''],
      ['id'=>'ppz7','name'=>'Ing. Jozef Medveď, PhD.','bio'=>''],
      ['id'=>'ppz8','name'=>'Kandidátka č. 8: doc. JUDr. Henrieta Vavrová, PhD.','bio'=>''],
      ['id'=>'ppz9','name'=>'Ing. Roman Kováč, PhD.','bio'=>''],
      ['id'=>'ppz10','name'=>'Kandidátka č. 10: prof. Ing. Klára Erbenová, DrSc.','bio'=>'']
    ];
    $url = 'https://hlasujeme.nasevolby.sk/volba-prezidenta-pz/';
    return $this->generate_output('Voľba Prezidenta Policajného zboru', '21/2025', $candidates, $url);
  }

  // ==========================================
  // SPOLOČNÁ GENERÁCIA VÝSTUPU PRE JAVASCRIPT
  // ==========================================
  private function generate_output($title, $vote_no, $candidates, $override_bios_url = ''){
    $crest = plugins_url('assets/logo-nase-volby-clean.png', __FILE__);
    $voter_name = 'Miroslav Petre';
    $district = '149';
    
    $bios_url = !empty($override_bios_url) ? $override_bios_url : 'https://hlasujeme.nasevolby.sk/?page_id=1878';
    $history_url = 'https://hlasujeme.nasevolby.sk/minule-hlasovania-buduce-hlasovania/571-2/';
    $total_voters = '4360505';

    ob_start(); ?>
    <div id="vmcv2-app"
         class="vmcv2-wrap vmcv2-fullbleed"
         data-candidates='<?php echo json_encode($candidates, JSON_UNESCAPED_UNICODE); ?>'
         data-crest="<?php echo esc_url($crest); ?>"
         data-vote-no="<?php echo esc_attr($vote_no); ?>"
         data-voter-name="<?php echo esc_attr($voter_name); ?>"
         data-district="<?php echo esc_attr($district); ?>"
         data-title="<?php echo esc_attr($title); ?>"
         data-bios-url="<?php echo esc_url($bios_url); ?>"
         data-history-url="<?php echo esc_url($history_url); ?>"
         data-total-voters="<?php echo esc_attr($total_voters); ?>"
         data-today="<?php echo esc_attr( date_i18n('j.n.Y, H:i:s') ); ?>"
    >
      <noscript>Na spustenie hlasovania je potrebný JavaScript.</noscript>
    </div>
    <?php return ob_get_clean();
  }
}
new Voting_Mobile_Univerzalny_Plugin();